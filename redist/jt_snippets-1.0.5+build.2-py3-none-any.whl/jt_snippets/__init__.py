from ._version import VERSION
